import React from "react";
import "./banner.css";
export default () => {
    return <div className="banner">
        <h1>Super Blog</h1>
        <p>Блок разработчиков React.js</p>
    </div>
}